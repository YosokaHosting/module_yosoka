# SCRIPT BOT HOSTING !! by yosnesia


<div align="center">
<img src="https://i.ibb.co/8zqD0Nx/IMG-20220810-WA0169.jpg" alt="YosokaCodeX" width="300" />

</p>
<h1 align="center">YOSOKA HOST</h1>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/YosokaHosting"><img title="GitHub" src="https://img.shields.io/badge/Github-ramlaidi.svg?style=for-the-badge&logo=github" /></a>
  <a href="httts://instagram.com/yosoka_hosting"><img title="Instagram " src="https://img.shields.io/badge/Instagram-yosoka.svg?style=for-the-badge&logo=instagram" /></a>
  <a href="https://youtube.com/channel/UCh6zcsGjETF83ocmz4gvCHg"><img title="Youtube" src="https://img.shields.io/badge/Youtube-YosokaNesia.svg?style=for-the-badge&logo=youtube" /></a>
  <h4 align="center">
  <a
  <a href="https://wa.me/6285891634201">Klik disini untuk WhatsApp Yosoka </a>
</h4>
</p>

## ```Donate Me```

- [`Saweria`](https://saweria.co/yosoka)
- [`All payment`](https://telegra.ph/YosokaHosting-07-18)
- [`Payment Ovo`](https://telegra.ph/Yosoka---Ovo-07-18)
- [`Payment Dana`](https://telegra.ph/Yosoka---Dana-07-18)
- [`Payment Gopay`](https://telegra.ph/YosokaHosting-07-18-2)

<p align="left">
Scan qr code from the above button, u can pay through Gopay , Dana , Ovo , Alpayment </p>
<p align="left"> Tidak
Menerima Nope / Nomor</p>
